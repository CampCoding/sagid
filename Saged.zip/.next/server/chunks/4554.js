"use strict";
exports.id = 4554;
exports.ids = [4554];
exports.modules = {

/***/ 46226:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97787);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(54641);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* __next_internal_client_entry_do_not_use__ default auto */ 


const LoadingButton = ({ children, loading = false, disabled = false, className = "", onClick, type = "button", ...props })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
        type: type,
        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("thm-btn relative", {
            "opacity-70 cursor-not-allowed": disabled || loading
        }, className),
        disabled: disabled || loading,
        onClick: onClick,
        ...props,
        children: [
            loading && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__/* .motion */ .E.div, {
                className: "absolute inset-0 flex items-center justify-center",
                initial: {
                    opacity: 0
                },
                animate: {
                    opacity: 1
                },
                exit: {
                    opacity: 0
                },
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                    className: "animate-spin h-5 w-5 text-white",
                    xmlns: "http://www.w3.org/2000/svg",
                    fill: "none",
                    viewBox: "0 0 24 24",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                            className: "opacity-25",
                            cx: "12",
                            cy: "12",
                            r: "10",
                            stroke: "currentColor",
                            strokeWidth: "4"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                            className: "opacity-75",
                            fill: "currentColor",
                            d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: loading ? "opacity-0" : "",
                children: children
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LoadingButton);


/***/ }),

/***/ 54702:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ toast)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_dom_client__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(89871);
/* harmony import */ var react_dom_client__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_dom_client__WEBPACK_IMPORTED_MODULE_2__);
/* __next_internal_client_entry_do_not_use__ toast,default auto */ 



const Toast = ({ message, type = "success", duration = 3000, onClose, position = "top-left" })=>{
    const [visible, setVisible] = useState(true);
    useEffect(()=>{
        const timer = setTimeout(()=>{
            setVisible(false);
            if (onClose) setTimeout(onClose, 300);
        }, duration);
        return ()=>clearTimeout(timer);
    }, [
        duration,
        onClose
    ]);
    const getIcon = ()=>{
        switch(type){
            case "success":
                return /*#__PURE__*/ _jsx("svg", {
                    className: "w-5 h-5",
                    viewBox: "0 0 20 20",
                    fill: "currentColor",
                    children: /*#__PURE__*/ _jsx("path", {
                        fillRule: "evenodd",
                        d: "M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z",
                        clipRule: "evenodd"
                    })
                });
            case "error":
                return /*#__PURE__*/ _jsx("svg", {
                    className: "w-5 h-5",
                    viewBox: "0 0 20 20",
                    fill: "currentColor",
                    children: /*#__PURE__*/ _jsx("path", {
                        fillRule: "evenodd",
                        d: "M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z",
                        clipRule: "evenodd"
                    })
                });
            default:
                return null;
        }
    };
    const getPositionClass = ()=>{
        switch(position){
            case "top-right":
                return "top-4 right-4";
            case "top-left":
                return "top-4 left-4";
            case "bottom-right":
                return "bottom-4 right-4";
            case "bottom-left":
                return "bottom-4 left-4";
            case "top-center":
                return "top-4 left-1/2 -translate-x-1/2";
            case "bottom-center":
                return "bottom-4 left-1/2 -translate-x-1/2";
            default:
                return "top-4 right-4";
        }
    };
    const bgColor = type === "success" ? "bg-green-50" : "bg-red-50";
    const textColor = type === "success" ? "text-green-600" : "text-red-600";
    const borderColor = type === "success" ? "border-green-400" : "border-red-400";
    const iconColor = type === "success" ? "text-green-500" : "text-red-500";
    return /*#__PURE__*/ _jsx(AnimatePresence, {
        children: visible && /*#__PURE__*/ _jsx(motion.div, {
            className: `fixed ${getPositionClass()} z-50 glassy ${bgColor} ${textColor} border ${borderColor} rounded-md shadow-lg max-w-sm`,
            initial: {
                opacity: 0,
                y: -50,
                scale: 0.9
            },
            animate: {
                opacity: 1,
                y: 0,
                scale: 1
            },
            exit: {
                opacity: 0,
                y: -20,
                scale: 0.9
            },
            transition: {
                type: "spring",
                stiffness: 300,
                damping: 20
            },
            children: /*#__PURE__*/ _jsxs("div", {
                className: "flex p-4 items-center",
                children: [
                    /*#__PURE__*/ _jsx("div", {
                        className: `flex-shrink-0 ${iconColor}`,
                        children: getIcon()
                    }),
                    /*#__PURE__*/ _jsx("div", {
                        className: "ml-3",
                        children: /*#__PURE__*/ _jsx("p", {
                            className: "text-sm font-medium",
                            children: message
                        })
                    }),
                    /*#__PURE__*/ _jsx("div", {
                        className: "ml-auto pl-3",
                        children: /*#__PURE__*/ _jsx("button", {
                            onClick: ()=>{
                                setVisible(false);
                                if (onClose) setTimeout(onClose, 300);
                            },
                            className: `inline-flex ${textColor} focus:outline-none`,
                            children: /*#__PURE__*/ _jsx("svg", {
                                className: "w-4 h-4",
                                viewBox: "0 0 20 20",
                                fill: "currentColor",
                                children: /*#__PURE__*/ _jsx("path", {
                                    fillRule: "evenodd",
                                    d: "M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z",
                                    clipRule: "evenodd"
                                })
                            })
                        })
                    })
                ]
            })
        })
    });
};
// Helper functions to show toasts
let toastContainer = null;
let toastId = 0;
const roots = new Map();
// Create container element if it doesn't exist
const createContainer = ()=>{
    if (typeof document !== "undefined") {
        if (!toastContainer) {
            toastContainer = document.createElement("div");
            toastContainer.id = "toast-container";
            toastContainer.style.position = "fixed";
            toastContainer.style.zIndex = "9999";
            toastContainer.style.top = "0";
            toastContainer.style.right = "0";
            toastContainer.style.padding = "1rem";
            document.body.appendChild(toastContainer);
        }
        return toastContainer;
    }
    return null;
};
// Render a toast
const renderToast = (message, type, duration)=>{
    if (typeof document !== "undefined" && "undefined" !== "undefined") {}
};
// Export toast functions
const toast = {
    success: (message, duration = 3000)=>renderToast(message, "success", duration),
    error: (message, duration = 3000)=>renderToast(message, "error", duration)
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (Toast)));


/***/ })

};
;