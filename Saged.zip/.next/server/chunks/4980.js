"use strict";
exports.id = 4980;
exports.ids = [4980];
exports.modules = {

/***/ 94307:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ About)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./components/elements/CounterUp.js + 1 modules
var CounterUp = __webpack_require__(58276);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/react-modal-video/lib/index.js
var lib = __webpack_require__(52679);
;// CONCATENATED MODULE: ./components/elements/VideoPopup.js
/* __next_internal_client_entry_do_not_use__ default auto */ 


function VideoPopup({ style, text }) {
    const [isOpen, setOpen] = useState(false);
    return /*#__PURE__*/ _jsxs(_Fragment, {
        children: [
            !style && /*#__PURE__*/ _jsx("a", {
                onClick: ()=>setOpen(true),
                className: "overlay-link lightbox-image video-fancybox ripple",
                children: /*#__PURE__*/ _jsx("span", {
                    className: "play-icon flaticon-play"
                })
            }),
            style === 1 && /*#__PURE__*/ _jsx("div", {
                className: "video-btn",
                children: /*#__PURE__*/ _jsxs("a", {
                    onClick: ()=>setOpen(true),
                    className: "overlay-link lightbox-image video-fancybox ripple",
                    children: [
                        /*#__PURE__*/ _jsx("span", {
                            className: "play-icon flaticon-play"
                        }),
                        " "
                    ]
                })
            }),
            style === 2 && /*#__PURE__*/ _jsxs("div", {
                className: "video-btn",
                children: [
                    /*#__PURE__*/ _jsx("a", {
                        onClick: ()=>setOpen(true),
                        className: "overlay-link lightbox-image video-fancybox ripple",
                        children: /*#__PURE__*/ _jsx("span", {
                            className: "play-icon flaticon-play"
                        })
                    }),
                    /*#__PURE__*/ _jsx("h6", {
                        children: text ? text : "Latest Program Video"
                    })
                ]
            }),
            style === 3 && /*#__PURE__*/ _jsx("div", {
                className: "video-btn",
                children: /*#__PURE__*/ _jsxs("a", {
                    onClick: ()=>setOpen(true),
                    className: "lightbox-image",
                    children: [
                        /*#__PURE__*/ _jsx("i", {
                            className: "customicon-play-button"
                        }),
                        /*#__PURE__*/ _jsx("span", {
                            className: "border-animation border-1"
                        }),
                        /*#__PURE__*/ _jsx("span", {
                            className: "border-animation border-2"
                        }),
                        /*#__PURE__*/ _jsx("span", {
                            className: "border-animation border-3"
                        })
                    ]
                })
            }),
            style === 4 && /*#__PURE__*/ _jsx("div", {
                className: "video-btn",
                children: /*#__PURE__*/ _jsx("a", {
                    onClick: ()=>setOpen(true),
                    className: "lightbox-image",
                    children: /*#__PURE__*/ _jsx("img", {
                        src: "/assets/images-4/icons/video-btn-1.png",
                        alt: ""
                    })
                })
            }),
            style === 5 && /*#__PURE__*/ _jsx("a", {
                onClick: ()=>setOpen(true),
                className: "video-btn overlay-link lightbox-image video-fancybox ripple",
                children: /*#__PURE__*/ _jsx("span", {
                    className: "fas fa-play"
                })
            }),
            /*#__PURE__*/ _jsx(ModalVideo, {
                channel: "youtube",
                autoplay: true,
                isOpen: isOpen,
                videoId: "vfhzo499OeA",
                onClose: ()=>setOpen(false)
            })
        ]
    });
}

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(11440);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/ui/IntersectedBgs.js


const IntersectedBgs = ()=>{
    return /*#__PURE__*/ _jsx("div", {
        className: "absolute inset-0 h-full w-full",
        children: /*#__PURE__*/ _jsx("svg", {
            className: "h-full w-full",
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 1422 800",
            opacity: "1",
            children: /*#__PURE__*/ _jsxs("g", {
                "stroke-width": "3.5",
                stroke: "#2daae1",
                fill: "none",
                "stroke-linecap": "butt",
                children: [
                    /*#__PURE__*/ _jsx("line", {
                        x1: "88",
                        y1: "0",
                        x2: "0",
                        y2: "88",
                        opacity: "0.36"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "88",
                        y1: "0",
                        x2: "176",
                        y2: "88",
                        opacity: "0.36"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "176",
                        y1: "0",
                        x2: "264",
                        y2: "88",
                        opacity: "0.76"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "352",
                        y1: "0",
                        x2: "264",
                        y2: "88",
                        opacity: "0.12"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "440",
                        y1: "0",
                        x2: "352",
                        y2: "88",
                        opacity: "0.59"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "440",
                        y1: "0",
                        x2: "528",
                        y2: "88",
                        opacity: "0.96"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "616",
                        y1: "0",
                        x2: "528",
                        y2: "88",
                        opacity: "0.72"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "616",
                        y1: "0",
                        x2: "704",
                        y2: "88",
                        opacity: "0.37"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "792",
                        y1: "0",
                        x2: "704",
                        y2: "88",
                        opacity: "0.56"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "792",
                        y1: "0",
                        x2: "880",
                        y2: "88",
                        opacity: "0.68"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "880",
                        y1: "0",
                        x2: "968",
                        y2: "88",
                        opacity: "0.94"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "968",
                        y1: "0",
                        x2: "1056",
                        y2: "88",
                        opacity: "0.93"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1144",
                        y1: "0",
                        x2: "1056",
                        y2: "88",
                        opacity: "0.08"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1232",
                        y1: "0",
                        x2: "1144",
                        y2: "88",
                        opacity: "0.10"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1232",
                        y1: "0",
                        x2: "1320",
                        y2: "88",
                        opacity: "0.41"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1408",
                        y1: "0",
                        x2: "1320",
                        y2: "88",
                        opacity: "0.27"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1496",
                        y1: "0",
                        x2: "1408",
                        y2: "88",
                        opacity: "0.32"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "88",
                        y1: "88",
                        x2: "0",
                        y2: "176",
                        opacity: "0.68"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "176",
                        y1: "88",
                        x2: "88",
                        y2: "176",
                        opacity: "0.49"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "176",
                        y1: "88",
                        x2: "264",
                        y2: "176",
                        opacity: "0.78"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "352",
                        y1: "88",
                        x2: "264",
                        y2: "176",
                        opacity: "0.38"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "440",
                        y1: "88",
                        x2: "352",
                        y2: "176",
                        opacity: "0.13"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "440",
                        y1: "88",
                        x2: "528",
                        y2: "176",
                        opacity: "0.39"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "528",
                        y1: "88",
                        x2: "616",
                        y2: "176",
                        opacity: "0.77"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "704",
                        y1: "88",
                        x2: "616",
                        y2: "176",
                        opacity: "0.56"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "792",
                        y1: "88",
                        x2: "704",
                        y2: "176",
                        opacity: "0.86"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "880",
                        y1: "88",
                        x2: "792",
                        y2: "176",
                        opacity: "0.87"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "968",
                        y1: "88",
                        x2: "880",
                        y2: "176",
                        opacity: "0.31"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1056",
                        y1: "88",
                        x2: "968",
                        y2: "176",
                        opacity: "0.27"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1144",
                        y1: "88",
                        x2: "1056",
                        y2: "176",
                        opacity: "0.38"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1232",
                        y1: "88",
                        x2: "1144",
                        y2: "176",
                        opacity: "0.86"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1232",
                        y1: "88",
                        x2: "1320",
                        y2: "176",
                        opacity: "0.85"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1320",
                        y1: "88",
                        x2: "1408",
                        y2: "176",
                        opacity: "0.84"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1408",
                        y1: "88",
                        x2: "1496",
                        y2: "176",
                        opacity: "0.20"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "88",
                        y1: "176",
                        x2: "0",
                        y2: "264",
                        opacity: "0.56"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "176",
                        y1: "176",
                        x2: "88",
                        y2: "264",
                        opacity: "0.51"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "176",
                        y1: "176",
                        x2: "264",
                        y2: "264",
                        opacity: "0.12"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "264",
                        y1: "176",
                        x2: "352",
                        y2: "264",
                        opacity: "0.85"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "440",
                        y1: "176",
                        x2: "352",
                        y2: "264",
                        opacity: "0.23"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "528",
                        y1: "176",
                        x2: "440",
                        y2: "264",
                        opacity: "0.70"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "616",
                        y1: "176",
                        x2: "528",
                        y2: "264",
                        opacity: "0.42"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "704",
                        y1: "176",
                        x2: "616",
                        y2: "264",
                        opacity: "0.69"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "792",
                        y1: "176",
                        x2: "704",
                        y2: "264",
                        opacity: "0.99"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "880",
                        y1: "176",
                        x2: "792",
                        y2: "264",
                        opacity: "0.36"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "968",
                        y1: "176",
                        x2: "880",
                        y2: "264",
                        opacity: "0.66"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1056",
                        y1: "176",
                        x2: "968",
                        y2: "264",
                        opacity: "0.42"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1144",
                        y1: "176",
                        x2: "1056",
                        y2: "264",
                        opacity: "0.39"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1232",
                        y1: "176",
                        x2: "1144",
                        y2: "264",
                        opacity: "0.68"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1232",
                        y1: "176",
                        x2: "1320",
                        y2: "264",
                        opacity: "0.86"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1320",
                        y1: "176",
                        x2: "1408",
                        y2: "264",
                        opacity: "0.48"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1496",
                        y1: "176",
                        x2: "1408",
                        y2: "264",
                        opacity: "0.33"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "88",
                        y1: "264",
                        x2: "0",
                        y2: "352",
                        opacity: "0.92"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "176",
                        y1: "264",
                        x2: "88",
                        y2: "352",
                        opacity: "0.40"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "264",
                        y1: "264",
                        x2: "176",
                        y2: "352",
                        opacity: "0.78"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "352",
                        y1: "264",
                        x2: "264",
                        y2: "352",
                        opacity: "0.23"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "352",
                        y1: "264",
                        x2: "440",
                        y2: "352",
                        opacity: "0.38"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "440",
                        y1: "264",
                        x2: "528",
                        y2: "352",
                        opacity: "0.18"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "616",
                        y1: "264",
                        x2: "528",
                        y2: "352",
                        opacity: "0.31"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "616",
                        y1: "264",
                        x2: "704",
                        y2: "352",
                        opacity: "0.16"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "792",
                        y1: "264",
                        x2: "704",
                        y2: "352",
                        opacity: "0.08"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "792",
                        y1: "264",
                        x2: "880",
                        y2: "352",
                        opacity: "0.80"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "968",
                        y1: "264",
                        x2: "880",
                        y2: "352",
                        opacity: "0.39"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1056",
                        y1: "264",
                        x2: "968",
                        y2: "352",
                        opacity: "0.50"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1144",
                        y1: "264",
                        x2: "1056",
                        y2: "352",
                        opacity: "0.61"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1232",
                        y1: "264",
                        x2: "1144",
                        y2: "352",
                        opacity: "0.17"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1320",
                        y1: "264",
                        x2: "1232",
                        y2: "352",
                        opacity: "0.56"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1408",
                        y1: "264",
                        x2: "1320",
                        y2: "352",
                        opacity: "0.18"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1496",
                        y1: "264",
                        x2: "1408",
                        y2: "352",
                        opacity: "0.95"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "0",
                        y1: "352",
                        x2: "88",
                        y2: "440",
                        opacity: "0.96"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "88",
                        y1: "352",
                        x2: "176",
                        y2: "440",
                        opacity: "0.53"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "264",
                        y1: "352",
                        x2: "176",
                        y2: "440",
                        opacity: "0.85"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "352",
                        y1: "352",
                        x2: "264",
                        y2: "440",
                        opacity: "0.35"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "440",
                        y1: "352",
                        x2: "352",
                        y2: "440",
                        opacity: "0.37"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "528",
                        y1: "352",
                        x2: "440",
                        y2: "440",
                        opacity: "0.15"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "616",
                        y1: "352",
                        x2: "528",
                        y2: "440",
                        opacity: "0.55"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "704",
                        y1: "352",
                        x2: "616",
                        y2: "440",
                        opacity: "0.70"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "704",
                        y1: "352",
                        x2: "792",
                        y2: "440",
                        opacity: "0.29"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "880",
                        y1: "352",
                        x2: "792",
                        y2: "440",
                        opacity: "0.31"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "880",
                        y1: "352",
                        x2: "968",
                        y2: "440",
                        opacity: "0.33"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1056",
                        y1: "352",
                        x2: "968",
                        y2: "440",
                        opacity: "0.30"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1056",
                        y1: "352",
                        x2: "1144",
                        y2: "440",
                        opacity: "0.64"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1144",
                        y1: "352",
                        x2: "1232",
                        y2: "440",
                        opacity: "0.07"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1232",
                        y1: "352",
                        x2: "1320",
                        y2: "440",
                        opacity: "0.17"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1408",
                        y1: "352",
                        x2: "1320",
                        y2: "440",
                        opacity: "0.56"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1496",
                        y1: "352",
                        x2: "1408",
                        y2: "440",
                        opacity: "0.78"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "88",
                        y1: "440",
                        x2: "0",
                        y2: "528",
                        opacity: "0.83"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "176",
                        y1: "440",
                        x2: "88",
                        y2: "528",
                        opacity: "0.18"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "264",
                        y1: "440",
                        x2: "176",
                        y2: "528",
                        opacity: "0.46"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "352",
                        y1: "440",
                        x2: "264",
                        y2: "528",
                        opacity: "0.26"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "440",
                        y1: "440",
                        x2: "352",
                        y2: "528",
                        opacity: "0.47"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "528",
                        y1: "440",
                        x2: "440",
                        y2: "528",
                        opacity: "0.70"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "528",
                        y1: "440",
                        x2: "616",
                        y2: "528",
                        opacity: "0.19"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "704",
                        y1: "440",
                        x2: "616",
                        y2: "528",
                        opacity: "0.75"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "792",
                        y1: "440",
                        x2: "704",
                        y2: "528",
                        opacity: "0.80"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "880",
                        y1: "440",
                        x2: "792",
                        y2: "528",
                        opacity: "0.96"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "880",
                        y1: "440",
                        x2: "968",
                        y2: "528",
                        opacity: "0.69"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1056",
                        y1: "440",
                        x2: "968",
                        y2: "528",
                        opacity: "0.73"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1144",
                        y1: "440",
                        x2: "1056",
                        y2: "528",
                        opacity: "0.76"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1144",
                        y1: "440",
                        x2: "1232",
                        y2: "528",
                        opacity: "0.59"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1320",
                        y1: "440",
                        x2: "1232",
                        y2: "528",
                        opacity: "0.88"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1408",
                        y1: "440",
                        x2: "1320",
                        y2: "528",
                        opacity: "0.09"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1496",
                        y1: "440",
                        x2: "1408",
                        y2: "528",
                        opacity: "0.30"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "0",
                        y1: "528",
                        x2: "88",
                        y2: "616",
                        opacity: "0.44"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "88",
                        y1: "528",
                        x2: "176",
                        y2: "616",
                        opacity: "0.84"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "264",
                        y1: "528",
                        x2: "176",
                        y2: "616",
                        opacity: "0.09"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "352",
                        y1: "528",
                        x2: "264",
                        y2: "616",
                        opacity: "0.09"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "440",
                        y1: "528",
                        x2: "352",
                        y2: "616",
                        opacity: "0.58"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "440",
                        y1: "528",
                        x2: "528",
                        y2: "616",
                        opacity: "0.58"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "616",
                        y1: "528",
                        x2: "528",
                        y2: "616",
                        opacity: "0.90"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "704",
                        y1: "528",
                        x2: "616",
                        y2: "616",
                        opacity: "0.87"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "704",
                        y1: "528",
                        x2: "792",
                        y2: "616",
                        opacity: "0.25"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "880",
                        y1: "528",
                        x2: "792",
                        y2: "616",
                        opacity: "0.30"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "880",
                        y1: "528",
                        x2: "968",
                        y2: "616",
                        opacity: "0.97"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1056",
                        y1: "528",
                        x2: "968",
                        y2: "616",
                        opacity: "0.48"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1144",
                        y1: "528",
                        x2: "1056",
                        y2: "616",
                        opacity: "0.25"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1144",
                        y1: "528",
                        x2: "1232",
                        y2: "616",
                        opacity: "0.88"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1232",
                        y1: "528",
                        x2: "1320",
                        y2: "616",
                        opacity: "0.57"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1320",
                        y1: "528",
                        x2: "1408",
                        y2: "616",
                        opacity: "0.24"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1496",
                        y1: "528",
                        x2: "1408",
                        y2: "616",
                        opacity: "0.62"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "88",
                        y1: "616",
                        x2: "0",
                        y2: "704",
                        opacity: "0.50"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "176",
                        y1: "616",
                        x2: "88",
                        y2: "704",
                        opacity: "0.22"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "176",
                        y1: "616",
                        x2: "264",
                        y2: "704",
                        opacity: "0.29"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "352",
                        y1: "616",
                        x2: "264",
                        y2: "704",
                        opacity: "0.62"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "440",
                        y1: "616",
                        x2: "352",
                        y2: "704",
                        opacity: "0.86"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "440",
                        y1: "616",
                        x2: "528",
                        y2: "704",
                        opacity: "0.34"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "528",
                        y1: "616",
                        x2: "616",
                        y2: "704",
                        opacity: "0.66"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "704",
                        y1: "616",
                        x2: "616",
                        y2: "704",
                        opacity: "0.90"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "792",
                        y1: "616",
                        x2: "704",
                        y2: "704",
                        opacity: "0.67"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "792",
                        y1: "616",
                        x2: "880",
                        y2: "704",
                        opacity: "0.91"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "880",
                        y1: "616",
                        x2: "968",
                        y2: "704",
                        opacity: "0.12"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1056",
                        y1: "616",
                        x2: "968",
                        y2: "704",
                        opacity: "0.21"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1144",
                        y1: "616",
                        x2: "1056",
                        y2: "704",
                        opacity: "0.71"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1144",
                        y1: "616",
                        x2: "1232",
                        y2: "704",
                        opacity: "0.83"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1232",
                        y1: "616",
                        x2: "1320",
                        y2: "704",
                        opacity: "0.14"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1408",
                        y1: "616",
                        x2: "1320",
                        y2: "704",
                        opacity: "0.83"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1408",
                        y1: "616",
                        x2: "1496",
                        y2: "704",
                        opacity: "0.33"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "0",
                        y1: "704",
                        x2: "88",
                        y2: "792",
                        opacity: "0.20"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "88",
                        y1: "704",
                        x2: "176",
                        y2: "792",
                        opacity: "0.14"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "264",
                        y1: "704",
                        x2: "176",
                        y2: "792",
                        opacity: "0.71"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "352",
                        y1: "704",
                        x2: "264",
                        y2: "792",
                        opacity: "0.70"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "440",
                        y1: "704",
                        x2: "352",
                        y2: "792",
                        opacity: "0.31"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "528",
                        y1: "704",
                        x2: "440",
                        y2: "792",
                        opacity: "0.15"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "528",
                        y1: "704",
                        x2: "616",
                        y2: "792",
                        opacity: "0.79"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "616",
                        y1: "704",
                        x2: "704",
                        y2: "792",
                        opacity: "0.66"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "792",
                        y1: "704",
                        x2: "704",
                        y2: "792",
                        opacity: "0.98"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "880",
                        y1: "704",
                        x2: "792",
                        y2: "792",
                        opacity: "0.21"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "968",
                        y1: "704",
                        x2: "880",
                        y2: "792",
                        opacity: "0.63"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1056",
                        y1: "704",
                        x2: "968",
                        y2: "792",
                        opacity: "0.60"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1144",
                        y1: "704",
                        x2: "1056",
                        y2: "792",
                        opacity: "0.76"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1144",
                        y1: "704",
                        x2: "1232",
                        y2: "792",
                        opacity: "0.15"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1320",
                        y1: "704",
                        x2: "1232",
                        y2: "792",
                        opacity: "0.70"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1408",
                        y1: "704",
                        x2: "1320",
                        y2: "792",
                        opacity: "0.79"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1408",
                        y1: "704",
                        x2: "1496",
                        y2: "792",
                        opacity: "0.86"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "0",
                        y1: "792",
                        x2: "88",
                        y2: "880",
                        opacity: "0.43"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "88",
                        y1: "792",
                        x2: "176",
                        y2: "880",
                        opacity: "0.62"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "264",
                        y1: "792",
                        x2: "176",
                        y2: "880",
                        opacity: "0.26"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "264",
                        y1: "792",
                        x2: "352",
                        y2: "880",
                        opacity: "0.11"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "440",
                        y1: "792",
                        x2: "352",
                        y2: "880",
                        opacity: "0.91"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "528",
                        y1: "792",
                        x2: "440",
                        y2: "880",
                        opacity: "0.81"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "528",
                        y1: "792",
                        x2: "616",
                        y2: "880",
                        opacity: "0.28"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "704",
                        y1: "792",
                        x2: "616",
                        y2: "880",
                        opacity: "0.98"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "792",
                        y1: "792",
                        x2: "704",
                        y2: "880",
                        opacity: "0.96"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "880",
                        y1: "792",
                        x2: "792",
                        y2: "880",
                        opacity: "0.86"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "968",
                        y1: "792",
                        x2: "880",
                        y2: "880",
                        opacity: "0.58"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "968",
                        y1: "792",
                        x2: "1056",
                        y2: "880",
                        opacity: "0.56"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1056",
                        y1: "792",
                        x2: "1144",
                        y2: "880",
                        opacity: "0.47"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1232",
                        y1: "792",
                        x2: "1144",
                        y2: "880",
                        opacity: "0.69"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1232",
                        y1: "792",
                        x2: "1320",
                        y2: "880",
                        opacity: "0.52"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1408",
                        y1: "792",
                        x2: "1320",
                        y2: "880",
                        opacity: "0.68"
                    }),
                    /*#__PURE__*/ _jsx("line", {
                        x1: "1496",
                        y1: "792",
                        x2: "1408",
                        y2: "880",
                        opacity: "0.34"
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const ui_IntersectedBgs = ((/* unused pure expression or super */ null && (IntersectedBgs)));

// EXTERNAL MODULE: ./components/ui/CustomTilt.js
var CustomTilt = __webpack_require__(88460);
;// CONCATENATED MODULE: ./components/sections/home3/About.js
/* __next_internal_client_entry_do_not_use__ default auto */ 





function About() {
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("section", {
            className: "about-one my-4 relative glassy-1 !rounded-none",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "container  magnetic-item",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "row",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-xl-6 col-lg-6",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "about-one__right",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "section-title text-right",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "section-title__tagline",
                                                children: "من نحن"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                className: "section-title__title",
                                                children: "مرحبا بك في True Smile Dental Clinic – خدمات طب الأسنان المتميزة"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "about-one__right-text-1",
                                        children: "بقيادة د. ساجد لؤي، بنقّدم لك رعایة متكاملة في مجال طب الأسنان، باستخدام أحدث التقنیات الطبیة، وبأعلى معاییر الجودة والراحة"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        className: "about-one__points list-unstyled",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                className: "!bg-blue-500/20 backdrop-blur-sm border border-blue-200/20 text-white ",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(CustomTilt["default"], {
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "about-one__points-single",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "about-one__points-icon",
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "icon-repair"
                                                                })
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                className: "about-one__points-text ",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                                        className: "about-one__points-title",
                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                            href: "#",
                                                                            children: "علاج جذور الأسنان "
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                        className: "about-one__points-subtitle",
                                                                        children: "علاج جذور الأسنان بأحدث التقنيات الطبية والحرفية"
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                className: "!bg-blue-500/20 backdrop-blur-sm border border-blue-200/20 text-white ",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(CustomTilt["default"], {
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "about-one__points-single",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "about-one__points-icon",
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "icon-phone"
                                                                })
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                className: "about-one__points-text",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                                        className: "about-one__points-title",
                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                            href: "#",
                                                                            children: "لتركيبات التجميلية"
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                        className: "about-one__points-subtitle",
                                                                        children: "تيجان وجسور وزركون بتصميم عالي الجودة والدقة"
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "contact",
                                        className: "thm-btn",
                                        children: "تواصل معنا"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-xl-6 col-lg-6",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "about-one__left",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "about-one__img wow slideInLeft h-[730px]",
                                    "data-wow-delay": "100ms",
                                    "data-wow-duration": "2500ms",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: "https://res.cloudinary.com/dkc5klynm/image/upload/v1752395483/ozkan-guner-KRJwZrjuKpE-unsplash_11zon_mobcoo.jpg",
                                            alt: "",
                                            className: "h-full object-cover"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "about-one__our-goal !bg-blue-500/20 backdrop-blur-md border border-blue-200/20 ",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "about-one__our-goal-sub-title",
                                                    children: "هدفنا:"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                    className: "about-one__our-goal-title text-black",
                                                    children: 'تحقيق ابتسامة صحية ومشرقة لكل مريض بأحدث التقنيات وأعلى معايير الراحة."'
                                                })
                                            ]
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                })
            })
        })
    });
}


/***/ }),

/***/ 50765:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Banner)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(11440);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var swiper_modules__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(11987);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2797);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(52593);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3002);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(89554);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(97787);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* __next_internal_client_entry_do_not_use__ default auto */ 





const swiperOptions = {
    modules: [
        swiper_modules__WEBPACK_IMPORTED_MODULE_2__/* .Autoplay */ .pt,
        swiper_modules__WEBPACK_IMPORTED_MODULE_2__/* .Pagination */ .tl,
        swiper_modules__WEBPACK_IMPORTED_MODULE_2__/* .Navigation */ .W_
    ],
    slidesPerView: 1,
    spaceBetween: 0,
    autoplay: {
        delay: 6000,
        disableOnInteraction: false
    },
    loop: true,
    // Navigation
    navigation: {
        nextEl: ".h1n",
        prevEl: ".h1p"
    },
    // Pagination
    pagination: {
        el: ".swiper-pagination",
        clickable: true
    }
};
function Banner() {
    const ref = (0,react__WEBPACK_IMPORTED_MODULE_4__.useRef)(null);
    const { scrollYProgress } = (0,framer_motion__WEBPACK_IMPORTED_MODULE_5__/* .useScroll */ .v)({
        target: ref,
        offset: [
            "start start",
            "end start"
        ]
    });
    // Smooth scale
    const rawScale = (0,framer_motion__WEBPACK_IMPORTED_MODULE_6__/* .useTransform */ .H)(scrollYProgress, [
        0,
        0.5,
        1
    ], [
        1,
        2,
        4
    ]);
    const scale = (0,framer_motion__WEBPACK_IMPORTED_MODULE_7__/* .useSpring */ .q)(rawScale, {
        stiffness: 100,
        damping: 30
    });
    // Smooth opacity
    const rawOpacity = (0,framer_motion__WEBPACK_IMPORTED_MODULE_6__/* .useTransform */ .H)(scrollYProgress, [
        0,
        0.2,
        0.4,
        0.6,
        0.8,
        1
    ], [
        1,
        0.8,
        0.6,
        0,
        0,
        0
    ]);
    const opacity = (0,framer_motion__WEBPACK_IMPORTED_MODULE_7__/* .useSpring */ .q)(rawOpacity, {
        stiffness: 100,
        damping: 30
    });
    // smooth x position
    const rawX = (0,framer_motion__WEBPACK_IMPORTED_MODULE_6__/* .useTransform */ .H)(scrollYProgress, [
        0,
        1
    ], [
        0,
        -400
    ]);
    const x = (0,framer_motion__WEBPACK_IMPORTED_MODULE_7__/* .useSpring */ .q)(rawX, {
        stiffness: 100,
        damping: 30
    });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_8__/* .motion */ .E.section, {
            style: {
                opacity
            },
            ref: ref,
            className: "main-slider-two main-slider-three clearfix  !fixed top-[100px] inset-0 z-[1] h-screen overflow-hidden select-none",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(swiper_react__WEBPACK_IMPORTED_MODULE_3__/* .Swiper */ .tq, {
                ...swiperOptions,
                className: "swiper-container thm-swiper__slider",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "swiper-wrapper",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_3__/* .SwiperSlide */ .o5, {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_8__/* .motion */ .E.div, {
                                    className: "swiper-slide",
                                    style: {
                                        scale
                                    },
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "image-layer-two",
                                            style: {
                                                backgroundImage: "url(https://res.cloudinary.com/dkc5klynm/image/upload/v1752331061/ozkan-guner-8K2vv2JMRBQ-unsplash_11zon_rxukim.jpg)"
                                            }
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_8__/* .motion */ .E.div, {
                                            style: {
                                                opacity,
                                                x
                                            },
                                            className: "container",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "row",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-xl-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "main-slider-two__content",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                className: "main-slider-two__sub-title",
                                                                children: "مرحبا بك في"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                                                                className: "main-slider-two__title",
                                                                children: [
                                                                    "True Smile Dental Clinic ",
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {})
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                className: "main-slider-two__text",
                                                                children: "بقيادة د. ساجد لؤي، بنقّدم لك رعایة متكاملة في مجال طب الأسنان، باستخدام أحدث التقنیات الطبیة، وبأعلى معاییر الجودة والراحة."
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "main-slider-two__btn-box",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                                                    href: "/appointment",
                                                                    className: "thm-btn main-slider-two__btn",
                                                                    children: "احجز موعدك الآن"
                                                                })
                                                            })
                                                        ]
                                                    })
                                                })
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_3__/* .SwiperSlide */ .o5, {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_8__/* .motion */ .E.div, {
                                    className: "swiper-slide",
                                    style: {
                                        scale
                                    },
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "image-layer-two",
                                            style: {
                                                backgroundImage: "url(https://res.cloudinary.com/dkc5klynm/image/upload/v1752331477/ozkan-guner-R8MoN4FV5q0-unsplash_11zon_kuqa60.jpg)"
                                            }
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_8__/* .motion */ .E.div, {
                                            style: {
                                                opacity,
                                                x
                                            },
                                            className: "container",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "row",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-xl-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "main-slider-two__content",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                className: "main-slider-two__sub-title",
                                                                children: "عيادة أسنان احترافية"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                                                                className: "main-slider-two__title",
                                                                children: [
                                                                    "خبراء في علاج وتجميل الأسنان",
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                                    "لابتسامة صحية وجميلة"
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                                className: "main-slider-two__text",
                                                                children: [
                                                                    "سواء كان لديك ألم ضرس، تنظيف عميق، أو زراعة أسنان—فريقنا الطبي المعتمد",
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                                    "جاهز لتقديم أفضل رعاية بأسلوب سريع ودقيق."
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "main-slider-two__btn-box",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                                                    href: "/appointment",
                                                                    className: "thm-btn main-slider-two__btn",
                                                                    children: "احجز موعدك الآن"
                                                                })
                                                            })
                                                        ]
                                                    })
                                                })
                                            })
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "swiper-pagination",
                        id: "main-slider-pagination"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "main-slider-two__nav",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "swiper-button-prev h1p cursor-pointer",
                                id: "main-slider__swiper-button-next",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                    className: "icon-right-arrow"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "swiper-button-next h1n cursor-pointer",
                                id: "main-slider__swiper-button-prev",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                    className: "icon-left-arrow"
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
}


/***/ }),

/***/ 70405:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Brand)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(11440);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var swiper_modules__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(11987);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2797);
/* __next_internal_client_entry_do_not_use__ default auto */ 



const swiperOptions = {
    modules: [
        swiper_modules__WEBPACK_IMPORTED_MODULE_2__/* .Autoplay */ .pt,
        swiper_modules__WEBPACK_IMPORTED_MODULE_2__/* .Pagination */ .tl,
        swiper_modules__WEBPACK_IMPORTED_MODULE_2__/* .Navigation */ .W_
    ],
    slidesPerView: 3,
    spaceBetween: 30,
    // autoplay: {
    //     delay: 2500,
    //     disableOnInteraction: false,
    // },
    loop: true,
    // Navigation
    navigation: {
        nextEl: ".srn",
        prevEl: ".srp"
    },
    // Pagination
    pagination: {
        el: ".swiper-pagination",
        clickable: true
    }
};
function Brand() {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            className: "brand-one",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "container",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "brand-one__inner",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_3__/* .Swiper */ .tq, {
                        ...swiperOptions,
                        className: "thm-swiper__slider swiper-container",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "swiper-wrapper",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_3__/* .SwiperSlide */ .o5, {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "swiper-slide",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: "assets/images/brand/brand-1-1.png",
                                            alt: ""
                                        })
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_3__/* .SwiperSlide */ .o5, {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "swiper-slide",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: "assets/images/brand/brand-1-2.png",
                                            alt: ""
                                        })
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_3__/* .SwiperSlide */ .o5, {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "swiper-slide",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: "assets/images/brand/brand-1-3.png",
                                            alt: ""
                                        })
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_3__/* .SwiperSlide */ .o5, {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "swiper-slide",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: "assets/images/brand/brand-1-4.png",
                                            alt: ""
                                        })
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_3__/* .SwiperSlide */ .o5, {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "swiper-slide",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: "assets/images/brand/brand-1-5.png",
                                            alt: ""
                                        })
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_3__/* .SwiperSlide */ .o5, {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "swiper-slide",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: "assets/images/brand/brand-1-1.png",
                                            alt: ""
                                        })
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_3__/* .SwiperSlide */ .o5, {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "swiper-slide",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: "assets/images/brand/brand-1-2.png",
                                            alt: ""
                                        })
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_3__/* .SwiperSlide */ .o5, {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "swiper-slide",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: "assets/images/brand/brand-1-3.png",
                                            alt: ""
                                        })
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_3__/* .SwiperSlide */ .o5, {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "swiper-slide",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: "assets/images/brand/brand-1-4.png",
                                            alt: ""
                                        })
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_3__/* .SwiperSlide */ .o5, {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "swiper-slide",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: "assets/images/brand/brand-1-5.png",
                                            alt: ""
                                        })
                                    })
                                })
                            ]
                        })
                    })
                })
            })
        })
    });
}


/***/ }),

/***/ 22242:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ TechRepairServices)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/smartphone.js
var smartphone = __webpack_require__(38674);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/tablet.js
var tablet = __webpack_require__(64671);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/laptop.js
var laptop = __webpack_require__(94345);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/zap.js
var zap = __webpack_require__(76494);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/shield.js
var shield = __webpack_require__(44901);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/arrow-left.js
var arrow_left = __webpack_require__(79803);
;// CONCATENATED MODULE: ./components/ui/blurry.js


const Blurry = ()=>{
    return /*#__PURE__*/ _jsx("div", {
        className: "absolute inset-0 top-0 left-0 bottom-0 right-0",
        children: /*#__PURE__*/ _jsxs("svg", {
            xmlns: "http://www.w3.org/2000/svg",
            version: "1.1",
            viewBox: "0 0 800 800",
            children: [
                /*#__PURE__*/ _jsx("defs", {
                    children: /*#__PURE__*/ _jsxs("linearGradient", {
                        x1: "50%",
                        y1: "0%",
                        x2: "50%",
                        y2: "100%",
                        id: "ffflurry-grad",
                        gradientTransform: "rotate(270)",
                        children: [
                            /*#__PURE__*/ _jsx("stop", {
                                "stop-color": "hsl(0, 0%, 100%)",
                                "stop-opacity": "1",
                                offset: "0%"
                            }),
                            /*#__PURE__*/ _jsx("stop", {
                                "stop-color": "hsl(230, 55%, 70%)",
                                "stop-opacity": "1",
                                offset: "45%"
                            }),
                            /*#__PURE__*/ _jsx("stop", {
                                "stop-color": "hsl(205, 69%, 80%)",
                                "stop-opacity": "1",
                                offset: "100%"
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ _jsx("rect", {
                    width: "100%",
                    height: "100%",
                    fill: "hsl(0, 0%, 100%)"
                }),
                /*#__PURE__*/ _jsxs("g", {
                    fill: "url(#ffflurry-grad)",
                    children: [
                        /*#__PURE__*/ _jsx("rect", {
                            width: "227",
                            height: "2",
                            x: "205.5",
                            y: "166",
                            rx: "1",
                            transform: "rotate(146, 319, 167)",
                            opacity: "0.79"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "88",
                            height: "2",
                            x: "270",
                            y: "100",
                            rx: "1",
                            transform: "rotate(146, 314, 101)",
                            opacity: "0.73"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "537",
                            height: "2",
                            x: "-122.5",
                            y: "342",
                            rx: "1",
                            transform: "rotate(146, 146, 343)",
                            opacity: "0.78"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "114",
                            height: "2",
                            x: "622",
                            y: "669",
                            rx: "1",
                            transform: "rotate(146, 679, 670)",
                            opacity: "0.31"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "106",
                            height: "2",
                            x: "282",
                            y: "273",
                            rx: "1",
                            transform: "rotate(146, 335, 274)",
                            opacity: "0.88"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "199",
                            height: "2",
                            x: "670.5",
                            y: "440",
                            rx: "1",
                            transform: "rotate(146, 770, 441)",
                            opacity: "0.94"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "381",
                            height: "2",
                            x: "175.5",
                            y: "211",
                            rx: "1",
                            transform: "rotate(146, 366, 212)",
                            opacity: "0.61"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "559",
                            height: "2",
                            x: "0.5",
                            y: "236",
                            rx: "1",
                            transform: "rotate(146, 280, 237)",
                            opacity: "0.74"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "95",
                            height: "2",
                            x: "66.5",
                            y: "401",
                            rx: "1",
                            transform: "rotate(146, 114, 402)",
                            opacity: "0.98"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "134",
                            height: "2",
                            x: "269",
                            y: "432",
                            rx: "1",
                            transform: "rotate(146, 336, 433)",
                            opacity: "0.75"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "343",
                            height: "2",
                            x: "232.5",
                            y: "262",
                            rx: "1",
                            transform: "rotate(146, 404, 263)",
                            opacity: "0.83"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "44",
                            height: "2",
                            x: "330",
                            y: "321",
                            rx: "1",
                            transform: "rotate(146, 352, 322)",
                            opacity: "0.10"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "213",
                            height: "2",
                            x: "479.5",
                            y: "691",
                            rx: "1",
                            transform: "rotate(146, 586, 692)",
                            opacity: "0.87"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "355",
                            height: "2",
                            x: "-43.5",
                            y: "457",
                            rx: "1",
                            transform: "rotate(146, 134, 458)",
                            opacity: "0.82"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "70",
                            height: "2",
                            x: "17",
                            y: "361",
                            rx: "1",
                            transform: "rotate(146, 52, 362)",
                            opacity: "0.94"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "174",
                            height: "2",
                            x: "-49",
                            y: "747",
                            rx: "1",
                            transform: "rotate(146, 38, 748)",
                            opacity: "0.49"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "306",
                            height: "2",
                            x: "508",
                            y: "365",
                            rx: "1",
                            transform: "rotate(146, 661, 366)",
                            opacity: "0.11"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "439",
                            height: "2",
                            x: "418.5",
                            y: "279",
                            rx: "1",
                            transform: "rotate(146, 638, 280)",
                            opacity: "0.61"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "668",
                            height: "2",
                            x: "75",
                            y: "349",
                            rx: "1",
                            transform: "rotate(146, 409, 350)",
                            opacity: "0.28"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "616",
                            height: "2",
                            x: "131",
                            y: "64",
                            rx: "1",
                            transform: "rotate(146, 439, 65)",
                            opacity: "0.55"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "109",
                            height: "2",
                            x: "80.5",
                            y: "267",
                            rx: "1",
                            transform: "rotate(146, 135, 268)",
                            opacity: "0.46"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "625",
                            height: "2",
                            x: "166.5",
                            y: "491",
                            rx: "1",
                            transform: "rotate(146, 479, 492)",
                            opacity: "0.59"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "300",
                            height: "2",
                            x: "584",
                            y: "575",
                            rx: "1",
                            transform: "rotate(146, 734, 576)",
                            opacity: "0.91"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "417",
                            height: "2",
                            x: "103.5",
                            y: "608",
                            rx: "1",
                            transform: "rotate(146, 312, 609)",
                            opacity: "0.40"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "537",
                            height: "2",
                            x: "164.5",
                            y: "765",
                            rx: "1",
                            transform: "rotate(146, 433, 766)",
                            opacity: "0.38"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "484",
                            height: "2",
                            x: "-18",
                            y: "170",
                            rx: "1",
                            transform: "rotate(146, 224, 171)",
                            opacity: "0.72"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "372",
                            height: "2",
                            x: "433",
                            y: "604",
                            rx: "1",
                            transform: "rotate(146, 619, 605)",
                            opacity: "0.87"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "453",
                            height: "2",
                            x: "513.5",
                            y: "396",
                            rx: "1",
                            transform: "rotate(146, 740, 397)",
                            opacity: "0.59"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "187",
                            height: "2",
                            x: "3.5",
                            y: "139",
                            rx: "1",
                            transform: "rotate(146, 97, 140)",
                            opacity: "0.87"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "265",
                            height: "2",
                            x: "350.5",
                            y: "17",
                            rx: "1",
                            transform: "rotate(146, 483, 18)",
                            opacity: "0.45"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "400",
                            height: "2",
                            x: "206",
                            y: "614",
                            rx: "1",
                            transform: "rotate(146, 406, 615)",
                            opacity: "0.14"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "757",
                            height: "2",
                            x: "2.5",
                            y: "529",
                            rx: "1",
                            transform: "rotate(146, 381, 530)",
                            opacity: "0.75"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "720",
                            height: "2",
                            x: "225",
                            y: "37",
                            rx: "1",
                            transform: "rotate(146, 585, 38)",
                            opacity: "0.38"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "359",
                            height: "2",
                            x: "-136.5",
                            y: "658",
                            rx: "1",
                            transform: "rotate(146, 43, 659)",
                            opacity: "0.11"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "615",
                            height: "2",
                            x: "254.5",
                            y: "140",
                            rx: "1",
                            transform: "rotate(146, 562, 141)",
                            opacity: "0.98"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "631",
                            height: "2",
                            x: "427.5",
                            y: "51",
                            rx: "1",
                            transform: "rotate(146, 743, 52)",
                            opacity: "0.10"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "106",
                            height: "2",
                            x: "513",
                            y: "334",
                            rx: "1",
                            transform: "rotate(146, 566, 335)",
                            opacity: "0.83"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "288",
                            height: "2",
                            x: "509",
                            y: "93",
                            rx: "1",
                            transform: "rotate(146, 653, 94)",
                            opacity: "0.58"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "224",
                            height: "2",
                            x: "179",
                            y: "323",
                            rx: "1",
                            transform: "rotate(146, 291, 324)",
                            opacity: "0.08"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "620",
                            height: "2",
                            x: "455",
                            y: "675",
                            rx: "1",
                            transform: "rotate(146, 765, 676)",
                            opacity: "0.32"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "81",
                            height: "2",
                            x: "116.5",
                            y: "26",
                            rx: "1",
                            transform: "rotate(146, 157, 27)",
                            opacity: "0.08"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "605",
                            height: "2",
                            x: "71.5",
                            y: "37",
                            rx: "1",
                            transform: "rotate(146, 374, 38)",
                            opacity: "0.74"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "707",
                            height: "2",
                            x: "388.5",
                            y: "164",
                            rx: "1",
                            transform: "rotate(146, 742, 165)",
                            opacity: "0.93"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "176",
                            height: "2",
                            x: "100",
                            y: "93",
                            rx: "1",
                            transform: "rotate(146, 188, 94)",
                            opacity: "0.21"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "806",
                            height: "2",
                            x: "180",
                            y: "527",
                            rx: "1",
                            transform: "rotate(146, 583, 528)",
                            opacity: "0.57"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "108",
                            height: "2",
                            x: "280",
                            y: "376",
                            rx: "1",
                            transform: "rotate(146, 334, 377)",
                            opacity: "0.13"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "308",
                            height: "2",
                            x: "320",
                            y: "136",
                            rx: "1",
                            transform: "rotate(146, 474, 137)",
                            opacity: "0.93"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "281",
                            height: "2",
                            x: "49.5",
                            y: "540",
                            rx: "1",
                            transform: "rotate(146, 190, 541)",
                            opacity: "0.22"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "903",
                            height: "2",
                            x: "-203.5",
                            y: "743",
                            rx: "1",
                            transform: "rotate(146, 248, 744)",
                            opacity: "0.36"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "45",
                            height: "2",
                            x: "178.5",
                            y: "435",
                            rx: "1",
                            transform: "rotate(146, 201, 436)",
                            opacity: "0.14"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "738",
                            height: "2",
                            x: "-162",
                            y: "267",
                            rx: "1",
                            transform: "rotate(146, 207, 268)",
                            opacity: "0.14"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "686",
                            height: "2",
                            x: "-54",
                            y: "491",
                            rx: "1",
                            transform: "rotate(146, 289, 492)",
                            opacity: "0.69"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "215",
                            height: "2",
                            x: "405.5",
                            y: "70",
                            rx: "1",
                            transform: "rotate(146, 513, 71)",
                            opacity: "0.65"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "361",
                            height: "2",
                            x: "423.5",
                            y: "440",
                            rx: "1",
                            transform: "rotate(146, 604, 441)",
                            opacity: "0.52"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "355",
                            height: "2",
                            x: "312.5",
                            y: "358",
                            rx: "1",
                            transform: "rotate(146, 490, 359)",
                            opacity: "0.07"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "182",
                            height: "2",
                            x: "306",
                            y: "138",
                            rx: "1",
                            transform: "rotate(146, 397, 139)",
                            opacity: "0.68"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "142",
                            height: "2",
                            x: "647",
                            y: "760",
                            rx: "1",
                            transform: "rotate(146, 718, 761)",
                            opacity: "0.26"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "232",
                            height: "2",
                            x: "367",
                            y: "281",
                            rx: "1",
                            transform: "rotate(146, 483, 282)",
                            opacity: "0.78"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "335",
                            height: "2",
                            x: "326.5",
                            y: "564",
                            rx: "1",
                            transform: "rotate(146, 494, 565)",
                            opacity: "0.29"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "511",
                            height: "2",
                            x: "-69.5",
                            y: "655",
                            rx: "1",
                            transform: "rotate(146, 186, 656)",
                            opacity: "0.81"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "138",
                            height: "2",
                            x: "439",
                            y: "739",
                            rx: "1",
                            transform: "rotate(146, 508, 740)",
                            opacity: "0.22"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "228",
                            height: "2",
                            x: "393",
                            y: "635",
                            rx: "1",
                            transform: "rotate(146, 507, 636)",
                            opacity: "0.87"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "136",
                            height: "2",
                            x: "523",
                            y: "768",
                            rx: "1",
                            transform: "rotate(146, 591, 769)",
                            opacity: "0.32"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "270",
                            height: "2",
                            x: "617",
                            y: "334",
                            rx: "1",
                            transform: "rotate(146, 752, 335)",
                            opacity: "0.92"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "205",
                            height: "2",
                            x: "-76.5",
                            y: "302",
                            rx: "1",
                            transform: "rotate(146, 26, 303)",
                            opacity: "0.69"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "460",
                            height: "2",
                            x: "360",
                            y: "215",
                            rx: "1",
                            transform: "rotate(146, 590, 216)",
                            opacity: "0.22"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "189",
                            height: "2",
                            x: "607.5",
                            y: "247",
                            rx: "1",
                            transform: "rotate(146, 702, 248)",
                            opacity: "1.00"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "218",
                            height: "2",
                            x: "240",
                            y: "755",
                            rx: "1",
                            transform: "rotate(146, 349, 756)",
                            opacity: "0.54"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "207",
                            height: "2",
                            x: "305.5",
                            y: "437",
                            rx: "1",
                            transform: "rotate(146, 409, 438)",
                            opacity: "0.86"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "156",
                            height: "2",
                            x: "45",
                            y: "196",
                            rx: "1",
                            transform: "rotate(146, 123, 197)",
                            opacity: "0.63"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "165",
                            height: "2",
                            x: "420.5",
                            y: "423",
                            rx: "1",
                            transform: "rotate(146, 503, 424)",
                            opacity: "0.75"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "376",
                            height: "2",
                            x: "584",
                            y: "264",
                            rx: "1",
                            transform: "rotate(146, 772, 265)",
                            opacity: "0.32"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "625",
                            height: "2",
                            x: "-80.5",
                            y: "339",
                            rx: "1",
                            transform: "rotate(146, 232, 340)",
                            opacity: "0.35"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "436",
                            height: "2",
                            x: "38",
                            y: "576",
                            rx: "1",
                            transform: "rotate(146, 256, 577)",
                            opacity: "0.88"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "248",
                            height: "2",
                            x: "-79",
                            y: "232",
                            rx: "1",
                            transform: "rotate(146, 45, 233)",
                            opacity: "0.19"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "473",
                            height: "2",
                            x: "234.5",
                            y: "208",
                            rx: "1",
                            transform: "rotate(146, 471, 209)",
                            opacity: "0.99"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "550",
                            height: "2",
                            x: "488",
                            y: "504",
                            rx: "1",
                            transform: "rotate(146, 763, 505)",
                            opacity: "0.93"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "718",
                            height: "2",
                            x: "-325",
                            y: "476",
                            rx: "1",
                            transform: "rotate(146, 34, 477)",
                            opacity: "0.87"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "38",
                            height: "2",
                            x: "321",
                            y: "677",
                            rx: "1",
                            transform: "rotate(146, 340, 678)",
                            opacity: "0.80"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "296",
                            height: "2",
                            x: "535",
                            y: "484",
                            rx: "1",
                            transform: "rotate(146, 683, 485)",
                            opacity: "0.66"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "496",
                            height: "2",
                            x: "11",
                            y: "408",
                            rx: "1",
                            transform: "rotate(146, 259, 409)",
                            opacity: "0.81"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "533",
                            height: "2",
                            x: "-194.5",
                            y: "43",
                            rx: "1",
                            transform: "rotate(146, 72, 44)",
                            opacity: "0.32"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "296",
                            height: "2",
                            x: "-121",
                            y: "107",
                            rx: "1",
                            transform: "rotate(146, 27, 108)",
                            opacity: "0.37"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "357",
                            height: "2",
                            x: "-72.5",
                            y: "518",
                            rx: "1",
                            transform: "rotate(146, 106, 519)",
                            opacity: "0.55"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "344",
                            height: "2",
                            x: "269",
                            y: "687",
                            rx: "1",
                            transform: "rotate(146, 441, 688)",
                            opacity: "0.79"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "409",
                            height: "2",
                            x: "64.5",
                            y: "38",
                            rx: "1",
                            transform: "rotate(146, 269, 39)",
                            opacity: "0.38"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "798",
                            height: "2",
                            x: "-270",
                            y: "748",
                            rx: "1",
                            transform: "rotate(146, 129, 749)",
                            opacity: "0.59"
                        }),
                        /*#__PURE__*/ _jsx("rect", {
                            width: "397",
                            height: "2",
                            x: "-120.5",
                            y: "594",
                            rx: "1",
                            transform: "rotate(146, 78, 595)",
                            opacity: "0.68"
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const blurry = ((/* unused pure expression or super */ null && (Blurry)));

// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(57114);
// EXTERNAL MODULE: ./node_modules/classnames/index.js
var classnames = __webpack_require__(54641);
;// CONCATENATED MODULE: ./components/ui/LettersPullUp.jsx
/* __next_internal_client_entry_do_not_use__ LettersPullUp auto */ 



function LettersPullUp({ text, className = "" }) {
    const splittedText = text.split("");
    const pullupVariant = {
        initial: {
            y: 10,
            opacity: 0
        },
        animate: (i)=>({
                y: 0,
                opacity: 1,
                transition: {
                    delay: i * 0.05
                }
            })
    };
    const ref = useRef(null);
    const isInView = useInView(ref, {
        once: true
    });
    return /*#__PURE__*/ _jsx("div", {
        className: "flex justify-center ",
        children: splittedText.map((current, i)=>/*#__PURE__*/ _jsx(motion.h2, {
                ref: ref,
                variants: pullupVariant,
                initial: "initial",
                animate: isInView ? "animate" : "",
                custom: i,
                className: cx("text-5xl md:text-6xl !font-bold text-gray-800 mb-6 leading-tight  ", className),
                children: current === " " ? /*#__PURE__*/ _jsx("span", {
                    children: "\xa0"
                }) : current
            }, i))
    });
}

;// CONCATENATED MODULE: ./components/sections/home3/Services.js
/* __next_internal_client_entry_do_not_use__ default auto */ 












function TechRepairServices() {
    const [hoveredCard, setHoveredCard] = (0,react_.useState)(null);
    const [isVisible, setIsVisible] = (0,react_.useState)(false);
    (0,react_.useEffect)(()=>{
        setIsVisible(true);
    }, []);
    const services = [
        {
            id: 1,
            title: "الفحص والتنظيف الوقائي",
            description: "علاج الأسنان الاحترافي بتقنيات طبية متقدمة وحرفية عالية",
            icon: smartphone/* default */.Z,
            image: "https://res.cloudinary.com/dkc5klynm/image/upload/v1752393734/atikah-akhtar-hKaYlAF1nDw-unsplash_11zon_v3dcjj.jpg",
            features: [
                "كشف شامل باستخدام األشعة الرقمية",
                "إزالة الجير وتلميع الأسنان",
                "حماية بالفلورايد وتوجيهات للعناية المنزلية"
            ],
            color: "from-yellow-500 to-yellow-400",
            path: "appointment"
        },
        {
            id: 2,
            title: "حشوات الأسنان التجميلية",
            description: "حشوات تجميلية بلون الأسنان لملء العيوب واستعادة الشكل الطبيعي والقوة في جلسة واحدة.",
            icon: tablet/* default */.Z,
            image: "https://res.cloudinary.com/dkc5klynm/image/upload/v1752392183/pexels-cedric-fauntleroy-4269684_11zon_zhdgyn.jpg",
            features: [
                "حشوات بلون السن الطبيعي (كومبوزيت)",
                "علاج يتتسعل واالتسوس والحشوا بالع عالیب"
            ],
            color: "from-yellow-500 to-yellow-400",
            path: "appointment"
        },
        {
            id: 3,
            title: "جراحات الفم",
            description: "جراحات صغيرة لعالج التهابات أو مشاكل فموية",
            icon: laptop/* default */.Z,
            image: "https://res.cloudinary.com/dkc5klynm/image/upload/v1752391989/pexels-karolina-grabowska-6627567_11zon_ykqofi.jpg",
            features: [
                "خلع ضروس العقل والضروس المطمورة",
                "جراحات صغيرة لعالج التهابات أو مشاكل فموية"
            ],
            color: "from-yellow-500 to-yellow-400",
            path: "appointment"
        }
    ];
    const router = (0,navigation.useRouter)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "relative min-h-screen   overflow-hidden",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "absolute inset-0 overflow-hidden pointer-events-none",
                children: [
                    ...Array(6)
                ].map((_, i)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: `absolute w-2 h-2 bg-gradient-to-r from-blue-400 to-purple-400 rounded-full animate-pulse`,
                        style: {
                            left: `${Math.random() * 100}%`,
                            top: `${Math.random() * 100}%`,
                            animationDelay: `${i * 0.5}s`,
                            animationDuration: `${2 + Math.random() * 2}s`
                        }
                    }, i))
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "relative z-10 container mx-auto px-6 py-20",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: `text-center mb-16 transform transition-all duration-1000 `,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "  inline-flex items-center gap-2 bg-gradient-to-r  from-blue-500 to-cyan-400 text-white px-6 py-2 rounded-full text-base font-medium mb-6 shadow-lg",
                                children: "خدماتنا"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "bg-gradient-to-r from-blue-600 via-purple-600 to-cyan-500 bg-clip-text text-transparent",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "text-5xl md:text-6xl font-bold text-gray-800 mb-6 leading-tight",
                                    children: "خدماتنا المتميزة"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-xl text-gray-600 max-w-2xl mx-auto leading-relaxed",
                                children: "خدمات علاج الأسنان الاحترافية بتقنيات طبية متقدمة وحرفية عالية."
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flex  flex-col lg:flex-row  items-start justify-center  gap-8 max-w-7xl mx-auto",
                        children: services.map((service, index)=>{
                            const Icon = service.icon;
                            const isHovered = hoveredCard === service.id;
                            return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: `group w-full relative transform transition-all duration-700 ${isVisible ? "translate-y-0 opacity-100" : "translate-y-20 opacity-0"}`,
                                style: {
                                    transitionDelay: `${index * 200}ms`
                                },
                                onMouseEnter: ()=>setHoveredCard(service.id),
                                onMouseLeave: ()=>setHoveredCard(null),
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: `relative rounded-3xl p-8 h-full shadow-xl transition-all duration-500 hover:shadow-2xl hover:-translate-y-2 magnetic-item glassy-1 ${isHovered ? "scale-105 " : ""}`,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: `absolute inset-0 rounded-3xl bg-gradient-to-r ${service.color} opacity-0 group-hover:opacity-20 transition-opacity duration-500 blur-xl`
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "relative mb-6 overflow-hidden rounded-2xl",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                    src: service.image,
                                                    alt: service.title,
                                                    className: `w-full h-48 object-cover transition-transform duration-700 ${isHovered ? "scale-110" : "scale-100"}`
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: `absolute inset-0 bg-gradient-to-r ${service.color} opacity-20 transition-opacity duration-500`
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "space-y-4",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                    className: "text-2xl font-bold text-gray-800 group-hover:text-transparent group-hover:bg-gradient-to-r group-hover:from-blue-600 group-hover:to-purple-600 group-hover:bg-clip-text transition-all duration-300",
                                                    children: service.title
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: `space-y-2 overflow-hidden transition-all duration-500 ${isHovered ? "h-32 opacity-100" : "h-0 opacity-0"}`,
                                                    children: service.features.map((feature, idx)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "flex items-center gap-2 text-sm text-gray-600",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx(zap/* default */.Z, {
                                                                    className: "w-3 h-3 text-green-500"
                                                                }),
                                                                feature
                                                            ]
                                                        }, idx))
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: `pt-4 transition-all duration-500 ${isHovered ? "translate-y-0 opacity-100" : "translate-y-4 opacity-0 hidden"}`,
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                                        onClick: ()=>{
                                                            router.push(`/${service.path}`);
                                                        },
                                                        className: `w-full bg-gradient-to-r ${service.color} text-white py-3 px-6 rounded-xl font-medium flex items-center justify-center gap-2 hover:shadow-lg transition-all duration-300 group/btn`,
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx(shield/* default */.Z, {
                                                                className: "w-4 h-4"
                                                            }),
                                                            "احجز الآن",
                                                            /*#__PURE__*/ jsx_runtime_.jsx(arrow_left/* default */.Z, {
                                                                className: "w-4 h-4 group-hover/btn:translate-x-1 transition-transform duration-300"
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }, service.id);
                        })
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 2427:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Skill)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_modal_video__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(52679);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ui_CustomTilt__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(88460);
/* __next_internal_client_entry_do_not_use__ default auto */ 



function Skill() {
    const [isOpen, setOpen] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                className: "skill-one",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "container",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "row",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-xl-6 col-lg-6",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "skill-one__left",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "section-title text-right",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "section-title__tagline",
                                                    children: "خدماتنا المتميزة"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                                                    className: "section-title__title",
                                                    children: [
                                                        "نتميز بالسرعة والكفاءة",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                        " في علاج الأسنان"
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "skill-one__text",
                                            children: "There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some words which don't look even slightly believable."
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "skill-one__text-2",
                                            children: "There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some words which don't look even slightly believable."
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "skill-one__progress glassy-1",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "skill-one__progress-single",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "bar border border-mobihubPrimary",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "bar-inner count-bar",
                                                            "data-percent": "84%",
                                                            style: {
                                                                width: "84%"
                                                            },
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "count-text",
                                                                    children: "84%"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                                                    className: "skill-one__progress-title",
                                                                    children: "Diagnostics"
                                                                })
                                                            ]
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "skill-one__progress-single ",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "bar",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "bar-inner count-bar",
                                                            "data-percent": "95%",
                                                            style: {
                                                                width: "95%"
                                                            },
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "count-text",
                                                                    children: "95%"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                                                    className: "skill-one__progress-title",
                                                                    children: "Replacment"
                                                                })
                                                            ]
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "skill-one__progress-single",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "bar marb-0",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "bar-inner count-bar",
                                                            "data-percent": "86%",
                                                            style: {
                                                                width: "86%"
                                                            },
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "count-text",
                                                                    children: "86%"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                                                    className: "skill-one__progress-title",
                                                                    children: "Device Repair"
                                                                })
                                                            ]
                                                        })
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-xl-6 col-lg-6 ",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "skill-one__right",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "skill-one__right-img-box wow slideInRight",
                                        "data-wow-delay": "100ms",
                                        "data-wow-duration": "2500ms",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "skill-one__right-img",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                        src: "assets/images/mobilehub/skill-1-1.jpg",
                                                        alt: ""
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "skill-one__video-link",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                            onClick: ()=>setOpen(true),
                                                            className: "video-popup",
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "skill-one__video-icon",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                        className: "fa fa-play"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                        className: "ripple"
                                                                    })
                                                                ]
                                                            })
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_CustomTilt__WEBPACK_IMPORTED_MODULE_3__["default"], {
                                                className: "skill-one__video-content glassy-1 !text-black",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    children: "Improve gadget smartphone laptop repair services"
                                                })
                                            })
                                        ]
                                    })
                                })
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_modal_video__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                channel: "youtube",
                autoplay: true,
                isOpen: isOpen,
                videoId: "Get7rqXYrbQ",
                onClose: ()=>setOpen(false)
            })
        ]
    });
}


/***/ }),

/***/ 70659:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Testimonial)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(11440);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var swiper_modules__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(11987);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2797);
/* harmony import */ var _ui_CustomTilt__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(88460);
/* __next_internal_client_entry_do_not_use__ default auto */ 




const swiperOptions = {
    modules: [
        swiper_modules__WEBPACK_IMPORTED_MODULE_2__/* .Autoplay */ .pt,
        swiper_modules__WEBPACK_IMPORTED_MODULE_2__/* .Pagination */ .tl,
        swiper_modules__WEBPACK_IMPORTED_MODULE_2__/* .Navigation */ .W_
    ],
    slidesPerView: 3,
    spaceBetween: 30,
    // autoplay: {
    //     delay: 2500,
    //     disableOnInteraction: false,
    // },
    breakpoints: {
        0: {
            slidesPerView: 1
        },
        768: {
            slidesPerView: 2
        },
        1024: {
            slidesPerView: 3
        }
    },
    loop: true,
    // Navigation
    navigation: {
        nextEl: ".srn",
        prevEl: ".srp"
    },
    // Pagination
    pagination: {
        el: ".swiper-pagination",
        clickable: true
    }
};
function Testimonial() {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            className: "testimonal-two",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "container",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "section-title section-title--two text-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "section-title__tagline",
                                children: "آراء المرضى"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                className: "section-title__title",
                                children: "تقييم عملائنا"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "section-title__text",
                                children: "ما يقوله مرضانا عن True Smile Dental Clinic"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(swiper_react__WEBPACK_IMPORTED_MODULE_3__/* .Swiper */ .tq, {
                        ...swiperOptions,
                        className: "testimonial-two__carousel owl-carousel owl-theme thm-owl__carousel",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_3__/* .SwiperSlide */ .o5, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "item",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_CustomTilt__WEBPACK_IMPORTED_MODULE_4__["default"], {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "testimonial-two__sinlge glassy-1 !shadow-none",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "testimonial-two__sinlge-inner",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "testimonial-two__quote",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "icon-quote"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                        className: "testimonial-two__text line-clamp-4",
                                                        children: "“في حفلة عيد ميلاد، شعرت بألم حاد في ضرس العقل. فريق True Smile عالجني في نفس اليوم”"
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "testimonial-two__info",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "testimonial-two__client-img",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                    src: "assets/images/mobilehub/testimonial-2-1.jpg",
                                                                    alt: "أحمد إبراهيم"
                                                                })
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "testimonial-two__content",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                                        className: "testimonial-two__client-name",
                                                                        children: "أحمد إبراهيم"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                        className: "testimonial-two__client-title",
                                                                        children: "موظف شركة"
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        })
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_3__/* .SwiperSlide */ .o5, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "item",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_CustomTilt__WEBPACK_IMPORTED_MODULE_4__["default"], {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "testimonial-two__sinlge glassy-1 !shadow-none",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "testimonial-two__sinlge-inner",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "testimonial-two__quote",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "icon-quote"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                        className: "testimonial-two__text line-clamp-4",
                                                        children: "“تعرضت للتسوس الشديد وخشيت أن أفقد أحد أسناني. بفضل رعاية True Smile Dental Clinic، استعدت ابتسامتي بثقة.”"
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "testimonial-two__info",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "testimonial-two__client-img",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                    src: "assets/images/mobilehub/testimonial-2-2.jpg",
                                                                    alt: "ليلى محمد"
                                                                })
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "testimonial-two__content",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                                        className: "testimonial-two__client-name",
                                                                        children: "ليلى محمد"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                        className: "testimonial-two__client-title",
                                                                        children: "طالبة جامعية"
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        })
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_3__/* .SwiperSlide */ .o5, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "item",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_CustomTilt__WEBPACK_IMPORTED_MODULE_4__["default"], {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "testimonial-two__sinlge glassy-1 !shadow-none",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "testimonial-two__sinlge-inner",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "testimonial-two__quote",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "icon-quote"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                        className: "testimonial-two__text line-clamp-4",
                                                        children: "“كنت أعاني من حساسية الأسنان وآلام اللثة المستمرة. بفضل العلاجات المتقدمة في True Smile، تحسنت حالتي تماماً!”"
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "testimonial-two__info",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "testimonial-two__client-img",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                    src: "assets/images/mobilehub/testimonial-2-2.jpg",
                                                                    alt: "سارة حسن"
                                                                })
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "testimonial-two__content",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                                        className: "testimonial-two__client-name",
                                                                        children: "سارة حسن"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                        className: "testimonial-two__client-title",
                                                                        children: "ممرضة"
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        })
                                    })
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
}


/***/ }),

/***/ 8195:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Welcome)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_modal_video__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(52679);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(11440);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(97787);
/* __next_internal_client_entry_do_not_use__ default auto */ 




function Welcome() {
    const [isOpen, setOpen] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
            className: "welcome-one",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "welcome-one__bg",
                    style: {
                        backgroundImage: "url(https://res.cloudinary.com/dkc5klynm/image/upload/v1752398655/4_wthzyt.png)",
                        backgroundSize: "cover"
                    }
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "container",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "row",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__/* .motion */ .E.div, {
                                className: "col-xl-6 order-2 col-lg-6 glassy-1 magnetic-item wow bounceInUp",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "welcome-one__left ",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "section-title text-right",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "section-title__tagline",
                                                    children: "مرحبا بك"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                    className: "section-title__title",
                                                    children: "True Smile Dental Clinic – خدمات طب الأسنان المتميزة"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "welcome-one__text-1",
                                            children: "بقيادة د. ساجد لؤي، بنقّدم لك رعایة متكاملة في مجال طب الأسنان، باستخدام أحدث التقنیات الطبیة، وبأعلى معاییر الجودة والراحة."
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                            className: "welcome-one__text-2",
                                            children: [
                                                "نعالج جميع حالات الأسنان في نفس اليوم باستخدام مواد طبيّة أصلية",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                "وخبرة طبية ودعم ودود يمكنك الاعتماد عليه."
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "welcome-one__btn-box",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                    href: "contact",
                                                    className: "welcome-one__btn thm-btn",
                                                    children: "تواصل معنا"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                    href: "about",
                                                    className: "welcome-one__btn-2 thm-btn",
                                                    children: "اكتشف المزيد"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-xl-6 col-lg-6 order-1",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "welcome-one__right",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "welcome-one__right-img wow fadeInRight",
                                        "data-wow-delay": "100ms",
                                        "data-wow-duration": "2500ms",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: "https://res.cloudinary.com/dkc5klynm/image/upload/v1752395024/vecteezy_ai-generated-dental-clinic-advertisment-background-with-copy_36594488_11zon_m3bybr.jpg",
                                            alt: ""
                                        })
                                    })
                                })
                            })
                        ]
                    })
                })
            ]
        })
    });
}


/***/ }),

/***/ 53407:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ZP: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports __esModule, $$typeof */
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61363);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`D:\CampCode\Saged-main\components\elements\CounterUp.js`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 93407:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ZP: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports __esModule, $$typeof */
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61363);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`D:\CampCode\Saged-main\components\sections\home3\About.js`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 86138:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ZP: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports __esModule, $$typeof */
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61363);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`D:\CampCode\Saged-main\components\sections\home3\Banner.js`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 47513:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (/* binding */ Blog)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(25124);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
// import Link from "next/link"
// export default function Blog() {
//     return (
//         <>
//         {/*Blog One Start*/}
//         <div className="blog-one">
//             <div className="blog-one-shape-1 float-bob-y"
//                 style={{ backgroundImage: 'url(assets/images/shapes/blog-one-shape-1.png)' }} >
//             </div>
//             <div className="container">
//                 <div className="section-title section-title--two text-center">
//                     <span className="section-title__tagline">From Our Blog</span>
//                     <h2 className="section-title__title">News And Articles</h2>
//                     <p className="section-title__text">Duis aute irure dolor in repreh enderit in volup tate velit esse
//                         cillum dolore <br/> eu fugiat nulla dolor atur with Lorem ipsum is simply </p>
//                 </div>
//                 <div className="row">
//                     {/*Blog One Single Start*/}
//                     <div className="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="100ms">
//                         <div className="blog-one__single glassy">
//                             <div className="blog-one__img">
//                                 <img src="assets/images/mobilehub/blog-1-1.jpg" alt=""/>
//                                 <div className="blog-one__plus">
//                                     <Link href="blog-details"><i className="fa fa-plus"></i></Link>
//                                 </div>
//                             </div>
//                             <div className="blog-one__content">
//                                 <ul className="blog-one__meta list-unstyled">
//                                     <li>
//                                         <Link href="blog-details"><i className="fa fa-calendar-alt"></i>5 AUG 2023</Link>
//                                     </li>
//                                     <li>
//                                         <Link href="blog-details"><i className="far fa-comments"></i>02 COMMENTS</Link>
//                                     </li>
//                                 </ul>
//                                 <h3 className="blog-one__title"><Link href="blog-details">How To Fix Broken Back Glass On
//                                         Your Phone</Link></h3>
//                                 <div className="blog-one__btn-box">
//                                     <Link href="blog-details" className="thm-btn blog-one__btn">Read More</Link>
//                                 </div>
//                             </div>
//                         </div>
//                     </div>
//                     {/*Blog One Single End*/}
//                     {/*Blog One Single Start*/}
//                     <div className="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="200ms">
//                         <div className="blog-one__single glassy">
//                             <div className="blog-one__img">
//                                 <img src="assets/images/mobilehub/blog-1-2.jpg" alt=""/>
//                                 <div className="blog-one__plus">
//                                     <Link href="blog-details"><i className="fa fa-plus"></i></Link>
//                                 </div>
//                             </div>
//                             <div className="blog-one__content">
//                                 <ul className="blog-one__meta list-unstyled">
//                                     <li>
//                                         <Link href="blog-details"><i className="fa fa-calendar-alt"></i>5 AUG 2023</Link>
//                                     </li>
//                                     <li>
//                                         <Link href="blog-details"><i className="far fa-comments"></i>02 COMMENTS</Link>
//                                     </li>
//                                 </ul>
//                                 <h3 className="blog-one__title"><Link href="blog-details">How To Fix Broken Screen On Your
//                                         Laptop</Link></h3>
//                                 <div className="blog-one__btn-box">
//                                     <Link href="blog-details" className="thm-btn blog-one__btn">Read More</Link>
//                                 </div>
//                             </div>
//                         </div>
//                     </div>
//                     {/*Blog One Single End*/}
//                     {/*Blog One Single Start*/}
//                     <div className="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="300ms">
//                         <div className="blog-one__single glassy">
//                             <div className="blog-one__img">
//                                 <img src="https://res.cloudinary.com/dbz6ebekj/image/upload/v1748870594/TR2V2_ey95kd.png" alt=""/>
//                                 <div className="blog-one__plus">
//                                     <Link href="blog-details"><i className="fa fa-plus"></i></Link>
//                                 </div>
//                             </div>
//                             <div className="blog-one__content">
//                                 <ul className="blog-one__meta list-unstyled">
//                                     <li>
//                                         <Link href="blog-details"><i className="fa fa-calendar-alt"></i>5 AUG 2023</Link>
//                                     </li>
//                                     <li>
//                                         <Link href="blog-details"><i className="far fa-comments"></i>02 COMMENTS</Link>
//                                     </li>
//                                 </ul>
//                                 <h3 className="blog-one__title"><Link href="blog-details">What Is The Best Affordable
//                                         Android Phone In 2023?</Link></h3>
//                                 <div className="blog-one__btn-box">
//                                     <Link href="blog-details" className="thm-btn blog-one__btn">Read More</Link>
//                                 </div>
//                             </div>
//                         </div>
//                     </div>
//                     {/*Blog One Single End*/}
//                 </div>
//             </div>
//         </div>
//         {/*Blog One End*/}
//         </>
//     )
// }


function Blog() {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "blog-one",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "blog-one-shape-1 float-bob-y",
                    style: {
                        backgroundImage: "url(assets/images/shapes/blog-one-shape-1.png)"
                    }
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "container",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "section-title section-title--two text-center",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "section-title__tagline",
                                    children: "From Our Blog"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                    className: "section-title__title",
                                    children: "Latest Tips, Repair Advice & Tech Insights"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    className: "section-title__text",
                                    children: [
                                        "Stay up to date with the latest in device care, smartphone trends, and expert repair tips — straight from the Mobihub MK team.",
                                        " "
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "row",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-xl-4 col-lg-4 wow fadeInUp",
                                    "data-wow-delay": "100ms",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "blog-one__single glassy-1 ",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "blog-one__img",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                        src: "assets/images/mobilehub/blog-1-1.jpg",
                                                        alt: ""
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "blog-one__plus",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                                            href: "blog-details",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                className: "fa fa-plus"
                                                            })
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "blog-one__content",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                                        className: "blog-one__meta list-unstyled",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                                                    href: "blog-details",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                            className: "fa fa-calendar-alt"
                                                                        }),
                                                                        "12 May 2025"
                                                                    ]
                                                                })
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                                                    href: "blog-details",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                            className: "far fa-comments"
                                                                        }),
                                                                        "02 COMMENTS"
                                                                    ]
                                                                })
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                        className: "blog-one__title",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                                            href: "blog-details",
                                                            children: "How To Fix Broken Back Glass On Your Phone"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "blog-one__btn-box",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                                            href: "blog-details",
                                                            className: "thm-btn blog-one__btn",
                                                            children: "Read More"
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-xl-4 col-lg-4 wow fadeInUp",
                                    "data-wow-delay": "200ms",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "blog-one__single glassy",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "blog-one__img",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                        src: "assets/images/mobilehub/blog-1-2.jpg",
                                                        alt: ""
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "blog-one__plus",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                                            href: "blog-details",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                className: "fa fa-plus"
                                                            })
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "blog-one__content",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                                        className: "blog-one__meta list-unstyled",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                                                    href: "blog-details",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                            className: "fa fa-calendar-alt"
                                                                        }),
                                                                        "23 May 2025"
                                                                    ]
                                                                })
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                                                    href: "blog-details",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                            className: "far fa-comments"
                                                                        }),
                                                                        "02 COMMENTS"
                                                                    ]
                                                                })
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                        className: "blog-one__title",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                                            href: "blog-details",
                                                            children: "How To Fix Broken Screen On Your Laptop"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "blog-one__btn-box",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                                            href: "blog-details",
                                                            className: "thm-btn blog-one__btn",
                                                            children: "Read More"
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-xl-4 col-lg-4 wow fadeInUp",
                                    "data-wow-delay": "300ms",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "blog-one__single glassy",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "blog-one__img",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                        src: "https://res.cloudinary.com/dbz6ebekj/image/upload/v1748870594/TR2V2_ey95kd.png",
                                                        alt: ""
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "blog-one__plus",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                                            href: "blog-details",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                className: "fa fa-plus"
                                                            })
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "blog-one__content",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                                        className: "blog-one__meta list-unstyled",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                                                    href: "blog-details",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                            className: "fa fa-calendar-alt"
                                                                        }),
                                                                        "1 June 2025"
                                                                    ]
                                                                })
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                                                    href: "blog-details",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                            className: "far fa-comments"
                                                                        }),
                                                                        "02 COMMENTS"
                                                                    ]
                                                                })
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                        className: "blog-one__title",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                                            href: "blog-details",
                                                            children: "What Is The Best Affordable Android Phone In 2025?"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "blog-one__btn-box",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                                            href: "blog-details",
                                                            className: "thm-btn blog-one__btn",
                                                            children: "Read More"
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
}


/***/ }),

/***/ 37916:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ZP: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports __esModule, $$typeof */
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61363);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`D:\CampCode\Saged-main\components\sections\home3\Brand.js`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 55267:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ Contact)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(61363);
;// CONCATENATED MODULE: ./components/ui/CustomTilt.js

const proxy = (0,module_proxy.createProxy)(String.raw`D:\CampCode\Saged-main\components\ui\CustomTilt.js`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const CustomTilt = ((/* unused pure expression or super */ null && (__default__)));
;// CONCATENATED MODULE: ./components/sections/home3/Contact.js


function Contact() {
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
            className: "contact-one",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "contact-one-bg jarallax",
                    style: {
                        backgroundImage: "url(https://res.cloudinary.com/dkc5klynm/image/upload/v1752398288/4_r9x7ds.png)"
                    }
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "container glassy magnetic-item",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "section-title section-title--two text-center",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "section-title__tagline !text-white",
                                    children: "تواصل معنا"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                    className: "section-title__title",
                                    children: "دعنا نتحدث – نحن هنا لمساعدتك"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "section-title__text",
                                    children: "هل لديك سؤال أو تحتاج لتقدير تكلفة العلاج؟ اترك لنا رسالة أو اتصل بنا — وسنعاود التواصل بسرعة."
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "contact-one__form-box",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                                action: "assets/inc/sendemail.php",
                                className: "contact-one__form contact-form-validated",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "row",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "col-xl-6 col-lg-6",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "contact-form__input-box",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                        type: "text",
                                                        placeholder: "الاسم",
                                                        name: "name",
                                                        className: "text-white placeholder:text-gray-200"
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "col-xl-6 col-lg-6",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "contact-form__input-box",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                        type: "text",
                                                        placeholder: "رقم الهاتف",
                                                        name: "phone",
                                                        className: "text-white placeholder:text-gray-200"
                                                    })
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "row",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "col-xl-12 col-lg-12",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "contact-form__input-box text-message-box",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                                                        name: "message",
                                                        placeholder: "رسالتك",
                                                        className: "text-white placeholder:text-gray-200"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "contact-form__btn-box magnetic-item",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                        type: "submit",
                                                        className: "thm-btn contact-form__btn",
                                                        children: "أرسل الرسالة"
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                })
            ]
        })
    });
}


/***/ }),

/***/ 99556:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (/* binding */ Features)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(25124);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);


function Features() {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            className: "feature-one",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "container",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "row justify-content-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-xl-3 col-lg-6 col-md-6 wow fadeInUp",
                            "data-wow-delay": "100ms",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "feature-one__single",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "feature-one__icon",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "icon-phone-call"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: "feature-one__title",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                            href: "services-details",
                                            children: "Provide Mobile Repair Services"
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-xl-3 col-lg-6 col-md-6 wow fadeInUp",
                            "data-wow-delay": "200ms",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "feature-one__single",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "feature-one__icon",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "icon-computer"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: "feature-one__title",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                            href: "services-details",
                                            children: "Provide Laptop & Computer Repair Services"
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-xl-3 col-lg-6 col-md-6 wow fadeInUp",
                            "data-wow-delay": "400ms",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "feature-one__single",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "feature-one__icon",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "icon-laptop-1"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: "feature-one__title",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                            href: "services-details",
                                            children: "Provide Tablet Repair Services"
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                })
            })
        })
    });
}


/***/ }),

/***/ 41849:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (/* binding */ Funfacts)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_elements_CounterUp__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(53407);


function Funfacts() {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
            className: "counter-one",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "counter-one__bg jarallax",
                    style: {
                        backgroundImage: "url(https://res.cloudinary.com/dkc5klynm/image/upload/v1752398182/1_czmbuo.png)"
                    }
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "container",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "row",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-xl-12",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                className: "counter-one__list list-unstyled",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                        className: "counter-one__single",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_elements_CounterUp__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
                                                end: 10
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "counter-one__plus",
                                                children: "+"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "counter-one__text",
                                                children: "سنوات مجيدة"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                        className: "counter-one__single",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_elements_CounterUp__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
                                                end: 22
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "counter-one__plus",
                                                children: "k+"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "counter-one__text",
                                                children: "عملاء سعداء"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                        className: "counter-one__single",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_elements_CounterUp__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
                                                end: 10
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "counter-one__plus",
                                                children: "k+"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "counter-one__text",
                                                children: "خدمات مكتملة"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                        className: "counter-one__single",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_elements_CounterUp__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
                                                end: 99
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "counter-one__plus",
                                                children: "%"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "counter-one__text",
                                                children: "رضا العملاء"
                                            })
                                        ]
                                    })
                                ]
                            })
                        })
                    })
                })
            ]
        })
    });
}


/***/ }),

/***/ 566:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (/* binding */ Process)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(25124);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);


function Process() {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
            className: "process-one",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "process-one__bg jarallax",
                    style: {
                        backgroundImage: "url(https://res.cloudinary.com/dkc5klynm/image/upload/v1752398418/2_11zon_zyu7xc.png)"
                    }
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "container",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "section-title text-center",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "section-title__tagline",
                                    children: "آلية العمل"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                    className: "section-title__title",
                                    children: "خطوات العلاج الأربع السهلة معنا"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "row",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-xl-3 col-lg-6 col-md-6",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "process-one__single",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "process-one__icon",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "icon-computer"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "process-one__count-box"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                className: "process-one__title",
                                                children: "حجز الموعد"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-xl-3 col-lg-6 col-md-6",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "process-one__single",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "process-one__icon",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "icon-send"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "process-one__count-box"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                className: "process-one__title",
                                                children: "الفحص والتشخيص"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-xl-3 col-lg-6 col-md-6",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "process-one__single",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "process-one__icon",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "icon-setting"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "process-one__count-box"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                className: "process-one__title",
                                                children: "العلاج والتنظيف"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-xl-3 col-lg-6 col-md-6",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "process-one__single",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "process-one__icon",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "icon-product"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "process-one__count-box"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                className: "process-one__title",
                                                children: "المتابعة والرعاية"
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
}


/***/ }),

/***/ 13881:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ZP: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports __esModule, $$typeof */
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61363);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`D:\CampCode\Saged-main\components\sections\home3\Services.js`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 84845:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ZP: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports __esModule, $$typeof */
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61363);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`D:\CampCode\Saged-main\components\sections\home3\Skill.js`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 97828:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ZP: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports __esModule, $$typeof */
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61363);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`D:\CampCode\Saged-main\components\sections\home3\Testimonial.js`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 6691:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ZP: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports __esModule, $$typeof */
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61363);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`D:\CampCode\Saged-main\components\sections\home3\Welcome.js`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;