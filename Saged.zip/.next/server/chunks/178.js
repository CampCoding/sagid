"use strict";
exports.id = 178;
exports.ids = [178];
exports.modules = {

/***/ 15536:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_layout_Layout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(23505);
/* harmony import */ var _components_BeforeAndAfter__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(20247);
/* __next_internal_client_entry_do_not_use__ default auto */ 


const BeforeAndAfterPage = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout_Layout__WEBPACK_IMPORTED_MODULE_1__["default"], {
        headerStyle: 3,
        footerStyle: 3,
        breadcrumbTitle: "Before And After",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "container my-7",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "columns-1 sm:columns-2 lg:columns-3 gap-4 space-y-4",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "break-inside-avoid",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_BeforeAndAfter__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                firstImage: {
                                    imageUrl: "/assets/images/before_after/image_2.png",
                                    alt: "Before Image"
                                },
                                secondImage: {
                                    imageUrl: "/assets/images/before_after/image_2-2.png",
                                    alt: "After Image"
                                }
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "break-inside-avoid",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_BeforeAndAfter__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                firstImage: {
                                    imageUrl: "/assets/images/before_after/image_3.png",
                                    alt: "Before Image"
                                },
                                secondImage: {
                                    imageUrl: "/assets/images/before_after/image_3-3.png",
                                    alt: "After Image"
                                }
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "break-inside-avoid",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_BeforeAndAfter__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                firstImage: {
                                    imageUrl: "/assets/images/before_after/image_4.png",
                                    alt: "Before Image"
                                },
                                secondImage: {
                                    imageUrl: "/assets/images/before_after/image_4-4.png",
                                    alt: "After Image"
                                }
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "break-inside-avoid",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_BeforeAndAfter__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                firstImage: {
                                    imageUrl: "/assets/images/before_after/image_5.png",
                                    alt: "Before Image"
                                },
                                secondImage: {
                                    imageUrl: "/assets/images/before_after/image5-5.png",
                                    alt: "After Image"
                                }
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "break-inside-avoid",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_BeforeAndAfter__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                firstImage: {
                                    imageUrl: "/assets/images/before_after/image_6.png",
                                    alt: "Before Image"
                                },
                                secondImage: {
                                    imageUrl: "/assets/images/before_after/image_6-6.png",
                                    alt: "After Image"
                                }
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "break-inside-avoid",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_BeforeAndAfter__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                firstImage: {
                                    imageUrl: "/assets/images/before_after/image_8.png",
                                    alt: "Before Image"
                                },
                                secondImage: {
                                    imageUrl: "/assets/images/before_after/image_8-8.png",
                                    alt: "After Image"
                                }
                            })
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BeforeAndAfterPage);


/***/ }),

/***/ 20247:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_before_after_slider_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(58861);
/* harmony import */ var react_before_after_slider_component__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_before_after_slider_component__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_before_after_slider_component_dist_build_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(36435);
/* harmony import */ var react_before_after_slider_component_dist_build_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_before_after_slider_component_dist_build_css__WEBPACK_IMPORTED_MODULE_3__);
// components/BeforeAfterSlider.js
/* __next_internal_client_entry_do_not_use__ default auto */ 



const BeforeAfterSliderComponent = ({ firstImage, secondImage })=>{
    const beforeImage = firstImage || "/assets/images/before_after/image_2.png";
    const afterImage = secondImage || "/assets/images/before_after/image_2-2.png";
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        dir: "ltr",
        className: "rounded-lg overflow-hidden h-full",
        style: {
            direction: "ltr"
        },
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_before_after_slider_component__WEBPACK_IMPORTED_MODULE_2___default()), {
            firstImage: firstImage,
            secondImage: secondImage
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BeforeAfterSliderComponent);


/***/ }),

/***/ 56260:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61363);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`D:\CampCode\Saged-main\app\before-and-after\page.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;